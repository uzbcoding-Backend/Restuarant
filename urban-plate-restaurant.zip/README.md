# Urban Plate Restaurant

A responsive restaurant frontend project made with HTML, CSS and vanilla JavaScript.

## Features
- Home page
- Restaurant menu with category filters
- Add-to-cart system
- Cart quantity controls
- Checkout and order placement
- Table booking form
- Orders and booking history
- About and Contact pages
- Responsive mobile navigation

## Important
This is a frontend demo project. Orders and bookings are saved in the browser using `localStorage`. No real payment, database, email, or restaurant backend is connected.

## Run
Open `index.html` in a browser, or deploy the project on GitHub Pages.
