const MENU_ITEMS=[
{id:1,name:'Bruschetta',category:'Starters',price:6.5,icon:'🥖',desc:'Tomato, basil, garlic and olive oil.'},
{id:2,name:'Caesar Salad',category:'Starters',price:8.9,icon:'🥗',desc:'Romaine, parmesan, croutons and Caesar dressing.'},
{id:3,name:'Creamy Truffle Pasta',category:'Pasta',price:14.9,icon:'🍝',desc:'Cream sauce, mushroom, truffle and parmesan.'},
{id:4,name:'Spicy Arrabbiata',category:'Pasta',price:11.5,icon:'🍝',desc:'Tomato sauce, chili, garlic and parsley.'},
{id:5,name:'Classic Burger',category:'Mains',price:12.9,icon:'🍔',desc:'Beef patty, cheddar, lettuce, tomato and sauce.'},
{id:6,name:'Grilled Chicken',category:'Mains',price:15.5,icon:'🍗',desc:'Herb grilled chicken with vegetables.'},
{id:7,name:'Pepperoni Pizza',category:'Pizza',price:13.9,icon:'🍕',desc:'Tomato, mozzarella and pepperoni.'},
{id:8,name:'Margherita Pizza',category:'Pizza',price:11.9,icon:'🍕',desc:'Tomato, mozzarella and fresh basil.'},
{id:9,name:'Chocolate Cake',category:'Desserts',price:6.2,icon:'🍰',desc:'Dark chocolate cake with soft center.'},
{id:10,name:'Tiramisu',category:'Desserts',price:6.8,icon:'🍮',desc:'Coffee, mascarpone and cocoa.'},
{id:11,name:'Lemonade',category:'Drinks',price:3.5,icon:'🍋',desc:'Fresh lemon, mint and sparkling water.'},
{id:12,name:'Iced Coffee',category:'Drinks',price:4.2,icon:'🧋',desc:'Cold coffee with milk and ice.'}
];
