const cart=JSON.parse(localStorage.getItem('urbanPlateCart')||'[]');
const count=cart.reduce((sum,item)=>sum+item.qty,0);
document.querySelectorAll('#cartCount').forEach(el=>el.textContent=count);
const year=document.getElementById('year');if(year)year.textContent=new Date().getFullYear();
const toggle=document.getElementById('menuToggle');const nav=document.getElementById('navLinks');if(toggle&&nav)toggle.addEventListener('click',()=>nav.classList.toggle('open'));
